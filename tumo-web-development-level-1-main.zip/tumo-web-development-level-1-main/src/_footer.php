<?php
include("_meta.php")
?>

<footer>
    <div class="icon-links">
        <a class="fs-3 link-dark link-underline-opacity-0 link-underline-opacity-0-hover" href="www.github.com/HamletSargsyan"><i class="bi bi-github"></i></a>
        <a class="fs-3 link-dark link-underline-opacity-0 link-underline-opacity-0-hover" href="www.instagram.com/h.a.m.l.e.t_s.a.r.g.s.y.a.n/"><i class="bi bi-instagram"></i></a>
        <a class="fs-3 link-dark link-underline-opacity-0 link-underline-opacity-0-hover" href="t.me/HamletSargsyan"><i class="bi bi-telegram"></i></a>
    </div>
</footer>